package application;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JComboBox;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BoardSelectionController implements Initializable{

	@FXML
	private ComboBox<String> BoardSelector;
	
	private static ObservableList<String> boardListIds = FXCollections.observableArrayList(); 
	
	private User user;

	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
		System.out.println("User " + user.getName() + " added");
	}

	public void ConfigAndStart(User user) {
		this.user = user;
		this.refreshBoards();
	}
	
	public ComboBox<String> getBoardSelector() {
		return BoardSelector;
	}

	public void setBoardSelector(ComboBox<String> boardList) {
		BoardSelector = boardList;
	}
	
	public void refreshBoards() {
		System.out.println("//" + user.getIpServer() + ":" + user.getPortServer() + "/GarticService");
		try {
			Gartic gartic = (Gartic) Naming.lookup("//" + user.getIpServer() + ":" + user.getPortServer() + "/GarticService");
			System.out.println(gartic.helloWorld());;
			ArrayList<String> l = (ArrayList<String>) gartic.getBoardsIds();
			this.boardListIds = FXCollections.observableArrayList();
			for(int i = 0; i < l.size(); i++) {
				this.boardListIds.add(l.get(i));
			}
			System.out.println("ObservableList size: " + this.boardListIds.size());
			this.BoardSelector.setItems(this.boardListIds);
			
		} catch (MalformedURLException e) {
			
			e.printStackTrace();
		} catch (RemoteException e) {
			 
			e.printStackTrace();
		} catch (NotBoundException e) {
			 
			e.printStackTrace();
		}
	}

	public BoardSelectionController() {
	}
	
	public BoardSelectionController(User u) {
		user = u;
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
//		this.refreshBoards();
	}
	
	public ObservableList<String> getBoardsListIds() {
		return boardListIds;
	}

	public void setBoardsListIds(ObservableList<String> boardsListIds) {
		this.boardListIds = boardsListIds;
	}

	@FXML
	public void onEnterButtonClicked() throws NotBoundException, IOException {
		System.out.println("Enter board button clicked: " + BoardSelector.getValue());
		Gartic gartic = (Gartic) Naming.lookup("//" + user.getIpServer() + ":" + user.getPortServer() + "/GarticService");
		String color = gartic.getColorBoard(Integer.parseInt(BoardSelector.getValue()));
		GarticController controller = new GarticController(this, Integer.parseInt(BoardSelector.getValue()), color);
		controller.showScreen();
	}
	
	public void onCreateButtonClicked() throws IOException {
		try {
			Gartic gartic = (Gartic) Naming.lookup("//" + user.getIpServer() + ":" + user.getPortServer() + "/GarticService");
			int id = gartic.createBoard();
			String color = gartic.getColorBoard(id);
			GarticController controller = new GarticController(this, id, color);
			controller.showScreen();

			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setBoardList(List<Board> boardList) {
//		this.comboBoxBoards.add(999); 
	}	
}
