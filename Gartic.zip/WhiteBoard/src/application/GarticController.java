package application;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.concurrent.Task;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class GarticController {

	@FXML
	private Button closeButton;
	
	
	@FXML
	private AnchorPane anchorPane;
	
//	private String ip;
	
//	private String port;
	
	private BoardSelectionController boardSelectionController;
	
	private double x1,y1,x2,y2;
     
	private Stage ownStage;
	
	private Line line;
	
//	private List<Line> lineList;
	private int contLines;
	
	private int boardId;
	
	private boolean firstClick = true;
	
	private boolean updateCond;
	
	private Gartic gartic;
	
	private String color;
	
	
	
	public Line createLine(double x1s, double y1s, double x2s, double y2s, String colors) {
		Line line2 = new Line();
        line2.setStartX(x1s);
        line2.setStartY(y1s);
        line2.setEndX(x2s);
        line2.setEndY(y2s);
//        line2.setStroke(Color.web(colors));
        line2.setStyle("-fx-stroke:" + colors);
//        System.out.println("x1: " + x1s + " y1: " + y1s);
//        System.out.println("x2: " + x2s + " y2: " + y2s);
//        System.out.println("-fx-stroke:" + colors);
//        lineList.add(line2);
        return line2;
	}
	
	public void showScreen() {
		this.ownStage.showAndWait();
	}
	
	
	Task<Void> updateLines = new Task<Void>() {

		@Override
		protected Void call() throws Exception {
			while(updateCond) {
				Platform.runLater(() -> {
                    try {
                        Gartic gartic = (Gartic) Naming.lookup("//" + boardSelectionController.getUser().getIpServer() + ":" + boardSelectionController.getUser().getPortServer() + "/GarticService");
                        List<String> list = gartic.getLinesList(boardId);
                        
                        System.out.println("Lines amount of board " + boardId +  ": " + list.size());
                        System.out.println("Cont lines: " + contLines);
                        if (contLines < list.size()) {
                        	if(contLines == 0) contLines = 1;
                        	for(int index = contLines - 1 ; index < list.size() ; index++) {
                        		Line l = new Line();
                        		String[] infos = list.get(index).split(",");
                        		l.setStartX(Double.valueOf(infos[0]));
                        		l.setStartY(Double.valueOf(infos[1]));
                        		l.setEndX(Double.valueOf(infos[2]));
                        		l.setEndY(Double.valueOf(infos[3]));
                        		l.setStyle(infos[4]);
                        		anchorPane.getChildren().add(l);
                        	}
                        	contLines = list.size();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                Thread.sleep(500);
			}
			return null;
		};
		
	};
	
	public void updateLinesFromServer() {
		System.out.println("updateLinesFromServer()");
	}
	
	public GarticController(BoardSelectionController bc, int boardId, String color2) throws IOException, NotBoundException {
		this.boardSelectionController = bc;
		this.ownStage = new Stage();
		this.contLines = 0;
		this.boardId = boardId;
		this.updateCond = true;
		this.color = color2;
//		System.out.println("This.coor:"  + this.color);

        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Gartic.fxml"));
        loader.setController(this);
        Scene scene = new Scene(loader.load());
        
        Gartic gartic = (Gartic) Naming.lookup("//" + bc.getUser().getIpServer() + ":" + bc.getUser().getPortServer() + "/GarticService");
        System.out.println(gartic.helloWorld());
        
        Thread t = new Thread(updateLines);
        t.setDaemon(true);
        t.start();
        
        
        scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
        	
        	@Override
            public void handle(MouseEvent mouseEvent) {
        		if(firstClick) {
        			x1 = mouseEvent.getX();
        			y1 = mouseEvent.getY();
        			firstClick = false;
        		}
        		else {
        			x2 = mouseEvent.getX();
        			y2 = mouseEvent.getY();
        			System.out.println("COLOR========== " + color);
        			line = createLine(x1,y1,x2,y2, color);
        	        

        	        anchorPane.getChildren().add(line);
        	        contLines++;
        	        
					try {
						gartic.addLine(boardId, line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY(), color);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        	        firstClick = true;
        			
        		}
        		System.out.println("Coordinates: (" + mouseEvent.getX() + ", " + mouseEvent.getY() + ")");
            }
        });
        ownStage.setScene(scene);
        intialize();
	}
	
	private void intialize() {
		// TODO Auto-generated method stub
		
	}

	@FXML public void OnCloseButtonClicked() {
		System.out.println("Close button clicked on Gartic Screen");
		Stage toClose = (Stage) closeButton.getScene().getWindow();
		updateCond = false;
		this.boardSelectionController.refreshBoards();

		toClose.close();
	}

	
}
