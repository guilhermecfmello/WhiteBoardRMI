package application;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class GarticImple extends UnicastRemoteObject implements Gartic {
	
	private List<Board> boardList = new ArrayList<Board>();
	private List<String> boardIdList = new ArrayList<String>();
	private int connectionsCont = 0;
	protected GarticImple() throws RemoteException {
		super();
//		this.boardList = new ArrayList<Board>();
	}

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String wbAdmin() throws RemoteException {
		String s = null;
		s = " ========== WB Admin =========== \n";
		s += "Made by: Guilherme Mello and Guilherme Fregatto\n";
		s += "Number of Boards: " + this.boardList.size() + "\n";
		int i, contLines = 0;
		for(i = 0; i < this.boardList.size(); i++){
			contLines += this.boardList.get(i).getLineList().size();
		}
		s += "Number of Lines: " + contLines + "\n";
		s += "Number of connections on server: " + this.connectionsCont + "\n";
		return s;
	}
	
	@Override
	public String helloWorld() throws RemoteException {
		String s = "Hello world, server is currently working";
		return s;
	}



	@Override
	public List<Line> getLines() throws RemoteException {
		return null;
	}

	@Override
	public List<Board> getBoards() throws RemoteException {
		return this.boardList;
	}
	
	

	@Override
	public int createBoard() throws RemoteException {
		try {
			Board newBoard = new Board();
			this.boardList.add(newBoard);
			this.boardIdList.add(Integer.toString(newBoard.getId()));
			this.connectionsCont++;
			return newBoard.getId();
		} catch (Exception e) {
			System.out.println("Has occurred an error on creating a new board: " + e.getMessage());
			e.printStackTrace();
			return -1;
		}
		
	}

	@Override
	public String getColorBoard(int boardId) throws RemoteException {
		
		return this.boardList.get(boardId).getColor();
	}

	@Override
	public int getNumberOfLines(int boardId) throws RemoteException {
		// TODO Auto-generated method stub
		return 0;
	}

	

	

	@Override
	public void addLine(int boardId, double x1, double y1, double x2, double y2, String color) throws RemoteException {
		
		Line line = new Line();
		line.setStartX(x1);
		line.setStartY(y1);
		line.setEndX(x2);
		line.setEndY(y2);
//		line.setStroke(Color.web(color));
		line.setStyle("-fx-stroke:" + color);
		line.setStrokeWidth(5);
		System.out.println("-fx-stroke:" + color);
		this.boardList.get(boardId).addLine(line);
//		System.out.println("Amount of lines of board (" + boardId + "): " + this.boardList.get(boardId).getLineList().size());
		
	}

	@Override
	public List<String> getBoardsIds() throws RemoteException {
		this.connectionsCont++;
		return this.boardIdList;
	}

	@Override
	public List<String> getLinesList(int boardId) throws RemoteException {
		List<Line> lines = this.boardList.get(boardId).getLineList();
		List<String> linesString = new ArrayList<String>();
		// x1,y1,x2,y2,color
		System.out.println("Lines.size(): " + lines.size());
		for(int i = 0; i < lines.size() ; i++) {
			String s = lines.get(i).getStartX() + ",";
			s += lines.get(i).getStartY() + ",";
			s += lines.get(i).getEndX() + ",";
			s += lines.get(i).getEndY() + ",";
			s += lines.get(i).getStyle();
			linesString.add(s);
			System.out.println("Line["+i+"]: " + s);
		}
		
		return linesString;
	}
	
}
