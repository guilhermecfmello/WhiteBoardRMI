package application;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class WbAdmin {

	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		
		Gartic gartic = (Gartic) Naming.lookup("//127.0.0.1:12345/GarticService");
		System.out.println(gartic.wbAdmin());
		

	}

}
