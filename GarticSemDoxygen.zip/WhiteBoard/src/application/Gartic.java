package application;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import javafx.scene.shape.Line;

public interface Gartic extends Remote {
	public String helloWorld() throws RemoteException;
//	public void addLine(int boardId, myLine line) throws RemoteException;
	public List<Line> getLines() throws RemoteException;
	public List<Board> getBoards() throws RemoteException;
	public int createBoard() throws RemoteException;
	public String getColorBoard(int boardId) throws RemoteException;
	public int getNumberOfLines(int boardId) throws RemoteException;
//	public void wbAdmin() throws RemoteException;
//	public void addLine(int boardId, Line line) throws RemoteException;
	public void addLine(int boardId, double x1, double y1, double x2, double y2, String color) throws RemoteException;
	public List<String> getBoardsIds() throws RemoteException;
	public List<String> getLinesList(int boardId) throws RemoteException;
	public String wbAdmin() throws RemoteException;
}
