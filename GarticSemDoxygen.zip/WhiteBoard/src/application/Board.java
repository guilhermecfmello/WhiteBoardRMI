package application;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.shape.Line;

public class Board implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static int count = 0;
	private int id;
	private List<Line> lineList;
	private List<String> colors;
	
	public int getId() {
		return id;
	}

	public Board() {
		this.lineList = new ArrayList<Line>();
		this.colors = new ArrayList<String>();
		this.id = this.count++;
		this.colors.add("black");
		this.colors.add("blue");
		this.colors.add("red");
		this.colors.add("magenta");
		this.colors.add("green");
		this.colors.add("yellow");
		this.colors.add("darkBlue");
	}
	
	public List<Line> getLineList() {
		return lineList;
	}

	public void setLineList(List<Line> lineList) {
		this.lineList = lineList;
	}

	public void addLine(Line l) {
		this.lineList.add(l);
		
	}
	
	public String getColor() {
		String colorReturn;
		if (this.colors.size() > 0){
			int size = this.colors.size();
			colorReturn = this.colors.get(size - 1); 
			this.colors.remove(size - 1);
		}
		else {
			colorReturn = "black";
		}
		return colorReturn;
	}
}
