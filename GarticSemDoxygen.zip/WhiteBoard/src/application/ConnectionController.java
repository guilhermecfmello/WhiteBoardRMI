package application;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.ResourceBundle;

import com.sun.javafx.logging.Logger;
import com.sun.media.jfxmediaimpl.platform.Platform;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ConnectionController implements Initializable{
	
	@FXML
	private TextField ip_input;
	
	@FXML
	private TextField port_input;
	
	@FXML
	private TextField name_input;
	
	@FXML
	private void onOkButtonClicked(ActionEvent event) {
		User newUser = new User(this.name_input.getText());
		newUser.setIpServer(ip_input.getText());
		newUser.setPortServer(port_input.getText());
		
		
		System.out.println("Ok button clicked");
		System.out.println("ip: " +  newUser.getIpServer());
		System.out.println("port: " + newUser.getPortServer());
		System.out.println("name: " + newUser.getName());
		
//		BoardSelectionController controller = new BoardSelectionController(newUser);
//		FXMLLoader loader = new FXMLLoader(getClass().getResource("boardselection.fxml"));
		
		
		FXMLLoader loader = new FXMLLoader();
		Pane p;
		try {
			p = loader.load(getClass().getResource("boardselection.fxml").openStream());
			
			
		} catch (IOException e) {
			System.out.println("Erro no loader: " + e.getMessage());
			e.printStackTrace();
		}
		BoardSelectionController controller = (BoardSelectionController) loader.getController();
		controller.ConfigAndStart(newUser);
//		controller.setUser(newUser);
//		controller.refreshBoards();
		
		Parent par = loader.getRoot();
		Stage stage = new Stage();
		stage.setScene(new Scene(par));
		stage.showAndWait();
	}
	
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.ip_input.setText("127.0.0.1");
		this.port_input.setText("12345");
		this.name_input.setText("usuario teste");
		
	}
}
