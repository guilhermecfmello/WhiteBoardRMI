package application;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;



public class GarticServer {
	static final int PORT = 12345;
	
	public GarticServer() {
		Registry reg = null;
		try {
			reg = LocateRegistry.createRegistry(PORT);
			Gartic gartic = new GarticImple();
			Naming.rebind("rmi://127.0.0.1:12345/GarticService", gartic);
			System.out.println("Server started on address= \"rmi://127.0.0.1:12345/GarticService\"");
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		new GarticServer();
	}
}
